from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView
from .views import RegistrationView, LoginView, getdata, ForgotOTPView, VerifyOTPView


urlpatterns = [
    path('register/',RegistrationView.as_view(),name="Register"),
    path('login/',LoginView.as_view(),name='Login'),
    path('data/',getdata.as_view(),name='data'),
    path('refresh/',TokenRefreshView.as_view(),name='refresh'),
    path('forgot-otp/',ForgotOTPView.as_view(),name='forget'),
    path('verify-otp/',VerifyOTPView.as_view(),name='verify'),


]
