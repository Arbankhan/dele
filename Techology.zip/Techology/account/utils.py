from django.core.mail import send_mail
from django.conf import settings

def activation_email(email,link):
    pass

def password_otp(otp,email):
    subject = "Password Reset"
    message = f"Your OTP is: {otp}, please verify in 15 min"
    send_mail(subject, message, settings.DEFAULT_FROM_EMAIL, [email])
