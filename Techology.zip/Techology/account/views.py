from rest_framework.views import APIView
from rest_framework.permissions import AllowAny
from .serializers import UserSerializer, SerializerVerifyOTP
from django.contrib.auth import authenticate, login
from rest_framework.response import Response
from rest_framework import status
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.permissions import IsAuthenticated
from django.contrib.auth import get_user_model
import random
from .models import OTP
from account.utils import password_otp
class RegistrationView(APIView):
    permission_classes = [AllowAny]
    def post(self,request):
        serializer = UserSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.create(serializer.validated_data)
            # uid = urlsafe_base64_encode(force_bytes(user.pk))
            # token = default_token_generator.make_token(user)
            # reset_link = reverse('activate_link', kwargs={'uid': uid, 'token': token})
            # reset_url = f'{settings.SITE_DOMAIN}{reset_link}'
            # activation_email(user.email, reset_url)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class LoginView(APIView):
    permission_classes = [AllowAny]
    def post(self,request):
        email = request.data.get('email')
        print(email)
        password = request.data.get('password')
        print(password)
        user = authenticate(request, email=email, password=password)
        if user is not None:
            if user.is_active:
                login(request, user)
                refresh = RefreshToken.for_user(user)
                data = {"access": str(refresh.access_token),"refresh": str(refresh),  "username": str(user.username),
                        "email": str(user.email)}
                return Response(data, status=status.HTTP_200_OK)
        else:
            return Response({'detail':'Email or Password is incorrect'},status=status.HTTP_400_BAD_REQUEST)


class ForgotOTPView(APIView):
    permission_classes = [AllowAny]

    def post(self,request):
        email = request.data.get("email")
        User = get_user_model()
        user = User.objects.get(email = email)
        if  user is not None:
            otp = ''.join(random.choice("0123456789") for _ in range(6))
            OTP.objects.create(user=user,otp=otp)
            password_otp(otp,user.email)
            return Response(data={'details':'mail sent'},status=status.HTTP_200_OK)
        else:
            return Response(data={'details': 'email not found'}, status=status.HTTP_400_BAD_REQUEST)


class VerifyOTPView(APIView):
    permission_classes = [AllowAny]

    def post(self,request):
        email = request.data.get("email")
        rec_otp = request.data.get("otp")
        password = request.data.get("password")
        confirm_password = request.data.get("confirm_password")
        serializer = SerializerVerifyOTP(data={'password':password ,'confirm_password':confirm_password})
        if serializer.is_valid():
            User = get_user_model()
            user = User.objects.get(email = email)
            otp = OTP.objects.filter(user=user.pk).order_by('id').latest('id')
            if otp.is_verified == False and rec_otp == otp.otp:
                if otp.created_at < otp.expire_at:
                    otp.is_verified = True
                    user.set_password(password)
                    user.save()
                    otp.save()
                    return Response(data={'details': 'otp verified'}, status=status.HTTP_200_OK)
                return Response(data={'details': 'otp expired'}, status=status.HTTP_400_BAD_REQUEST)
            return Response(data={'details': 'otp mismatch'}, status=status.HTTP_400_BAD_REQUEST)
        return Response(data={'details':serializer.errors }, status=status.HTTP_400_BAD_REQUEST)


class getdata(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):
        # Your view logic here
        return Response({"message": "Authenticated successfully"})

